package com.tfp.climbers.client;

public class CommonClientClass {

}
