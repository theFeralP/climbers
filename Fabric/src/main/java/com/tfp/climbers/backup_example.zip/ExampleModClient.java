package com.tfp.climbers;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.ModInitializer;

public class ExampleModClient implements ClientModInitializer {
    
    @Override
    public void onInitializeClient() {

    }
}
